
import { GoogleGenAI, Type } from "@google/genai";
import { SourceMaterial } from "../types";

const IS_DEV = false; // Mantenha como false para produção (Netlify)

const SUPPORTED_MIME_TYPES = [
  'image/png', 'image/jpeg', 'image/webp', 'image/heic', 'image/heif',
  'video/mp4', 'video/mpeg', 'video/mov', 'video/avi', 'video/x-flv', 'video/mpg', 'video/webm', 'video/wmv', 'video/3gpp',
  'audio/wav', 'audio/mp3', 'audio/aiff', 'audio/aac', 'audio/ogg', 'audio/flac',
  'application/pdf'
];

const DAILY_TIP_CACHE_KEY = 'esf_daily_tip_cache';

const getApiKey = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("ERRO CRÍTICO: Chave de API não encontrada. Verifique se a variável de ambiente API_KEY está configurada corretamente no seu ambiente de deploy (Netlify/Vercel).");
  }
  return apiKey || "";
};

const log = (...args: any[]) => {
  if (IS_DEV) console.log(...args);
};

const cleanJsonResponse = (text: string) => {
  if (!text) return "{}";
  let cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end !== -1) {
    cleaned = cleaned.substring(start, end + 1);
  }
  return cleaned;
};

export const chatWithMentor = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: "Você é o Mentor Sábio da ESF Finanças Teens. Seu objetivo é guiar jovens em finanças com sabedoria bíblica e técnica. Seja encorajador, use uma linguagem moderna mas sofisticada (luxo sustentável). Responda sempre em português.",
      },
      history: history
    });

    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error: any) {
    if (IS_DEV) console.error("Erro no Chat:", error);
    return "Desculpe, estou meditando em novos conselhos. Tente novamente em breve.";
  }
};

export const generateFinancialTip = async () => {
  const today = new Date().toDateString();
  
  try {
    const cached = localStorage.getItem(DAILY_TIP_CACHE_KEY);
    if (cached) {
      const { date, tipData } = JSON.parse(cached);
      if (date === today) {
        log("ESF: Carregando dica diária do cache local.");
        return tipData;
      }
    }
  } catch (e) {
    if (IS_DEV) console.warn("ESF: Falha ao ler cache de dicas.", e);
  }

  try {
    log("ESF: Gerando nova dica diária via Gemini API.");
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Gere uma reflexão financeira cristã curta para jovens da ESF Finanças Teens. Comece com um versículo bíblico.`,
      config: {
        tools: [{googleSearch: {}}],
        systemInstruction: "Você é o Mentor Cristão da ESF. Use princípios bíblicos e modernos.",
      }
    });

    const newTip = {
      text: response.text || "Planeje com sabedoria.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
        title: chunk.web?.title || "Fonte ESF",
        uri: chunk.web?.uri || "https://google.com"
      })) || []
    };

    try {
      localStorage.setItem(DAILY_TIP_CACHE_KEY, JSON.stringify({
        date: today,
        tipData: newTip
      }));
    } catch (e) {
      if (IS_DEV) console.warn("ESF: Não foi possível salvar a dica no localStorage.");
    }

    return newTip;
  } catch (error: any) {
    if (IS_DEV) console.error("Erro Tip:", error);
    return { text: '"Os planos bem elaborados levam à fartura..." (Provérbios 21:5).', sources: [] };
  }
};

export const generateLessonContent = async (title: string, materials: SourceMaterial[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const parts: any[] = [];

    materials.slice(0, 10).forEach(m => {
      if (m.type === 'text') {
        parts.push({ text: `Contexto do Mentor: ${m.content}` });
      } else if (SUPPORTED_MIME_TYPES.includes(m.mimeType)) {
        parts.push({
          inlineData: {
            data: m.content,
            mimeType: m.mimeType
          }
        });
      }
    });

    parts.push({ 
      text: `Baseado nos materiais, crie uma aula educativa para adolescentes chamada "${title}". 
      É OBRIGATÓRIO retornar EXATAMENTE 10 questões de múltipla escolha.
      Retorne um JSON com:
      1. 'summary': resumo denso.
      2. 'exercises': 3 cenários práticos.
      3. 'tests': 10 questões de múltipla escolha.
      4. 'article': Artigo formatado em Markdown.`
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
      config: {
        systemInstruction: "Diretor Pedagógico ESF. Responda APENAS JSON puro. Garanta 10 questões de teste.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            exercises: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: { scenario: { type: Type.STRING }, instructions: { type: Type.STRING } },
                required: ["scenario", "instructions"]
              }
            },
            tests: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctIndex: { type: Type.NUMBER },
                  explanation: { type: Type.STRING }
                },
                required: ["question", "options", "correctIndex", "explanation"]
              }
            },
            article: { type: Type.STRING }
          },
          required: ["summary", "exercises", "tests", "article"]
        }
      }
    });

    return JSON.parse(cleanJsonResponse(response.text || "{}"));
  } catch (error: any) {
    if (IS_DEV) console.error("Erro Gemini Lesson:", error);
    throw error;
  }
};

export const evaluatePracticeAnswer = async (scenario: string, instructions: string, answer: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Avalie: Cenário: ${scenario}, Instruções: ${instructions}, Resposta: ${answer}`,
      config: {
        systemInstruction: "Mentor ESF. Nota 0-100 e feedback motivador em JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { score: { type: Type.NUMBER }, feedback: { type: Type.STRING } },
          required: ["score", "feedback"]
        }
      }
    });
    return JSON.parse(cleanJsonResponse(response.text || '{"score":70,"feedback":"Processado"}'));
  } catch (error: any) {
    if (IS_DEV) console.error("Erro Avaliação:", error);
    return { score: 70, feedback: "Boa iniciativa!" };
  }
};

export const moderateComment = async (comment: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Modere: "${comment}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { safe: { type: Type.BOOLEAN }, reason: { type: Type.STRING } },
          required: ["safe", "reason"]
        }
      }
    });
    return JSON.parse(cleanJsonResponse(response.text || '{"safe":true,"reason":""}'));
  } catch (error: any) {
    if (IS_DEV) console.error("Erro Moderação:", error);
    return { safe: true, reason: "" };
  }
};
