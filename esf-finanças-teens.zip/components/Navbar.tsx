
import React from 'react';
import { User } from '../types';

interface NavbarProps {
  user: User | null;
}

const Navbar: React.FC<NavbarProps> = ({ user }) => {
  return null; // Logic moved to App.tsx for better state integration in this simple app
};

export default Navbar;
