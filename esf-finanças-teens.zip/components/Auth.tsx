
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { ShieldCheck, GraduationCap, Heart, Users, Sparkles, ChevronDown } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
  existingUsers: User[];
}

const Auth: React.FC<AuthProps> = ({ onLogin, existingUsers }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      const user = existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (user) {
        // Para fins de teste/demo, permitimos forçar o papel selecionado no login
        onLogin({ ...user, role: selectedRole });
      } else {
        // Se não existir, criamos um usuário temporário com o papel escolhido
        const newUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          name: email.split('@')[0],
          email,
          role: selectedRole,
          avatar: `https://picsum.photos/seed/${email}/200`,
          bio: `Membro ${selectedRole} na ESF!`
        };
        onLogin(newUser);
      }
    } else {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name,
        email,
        role: selectedRole,
        avatar: `https://picsum.photos/seed/${name}/200`,
        bio: `Novo entusiasta de finanças na ESF como ${selectedRole}!`
      };
      onLogin(newUser);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#4b5335] via-[#3a4a1c] to-[#c5a059] p-4 relative overflow-hidden">
      <div className="absolute top-10 left-10 text-white/10 rotate-12"><Heart size={80} /></div>
      <div className="absolute bottom-10 right-10 text-white/10 -rotate-12"><GraduationCap size={120} /></div>
      <div className="absolute top-1/2 left-[-20px] text-white/5"><Users size={150} /></div>

      <div className="bg-white/95 dark:bg-[#1e1e1e]/95 backdrop-blur-md rounded-[2.5rem] shadow-2xl w-full max-w-md p-10 border-4 border-white/20 dark:border-white/5 animate-in fade-in zoom-in duration-500">
        <div className="text-center mb-10">
          <div className="relative inline-block mb-6">
            <div className="absolute inset-0 bg-[#c5a059] blur-2xl opacity-20 rounded-full animate-pulse"></div>
            <img 
              src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" 
              alt="Logo ESF" 
              className="w-24 h-24 rounded-[2rem] object-cover mx-auto shadow-xl border-4 border-white dark:border-zinc-800 relative z-10"
            />
          </div>
          <h1 className="text-2xl font-black text-[#4b5335] dark:text-[#c5a059] mb-1 tracking-tighter uppercase">Escola de Sabedoria</h1>
          <p className="text-xs font-bold text-[#c5a059] tracking-[0.3em] uppercase mb-4">Financeira Teens</p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#4b5335] to-[#c5a059] mx-auto rounded-full mb-4"></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="animate-in slide-in-from-top-2">
              <label className="block text-[10px] font-bold text-[#4b5335] dark:text-[#c5a059] uppercase mb-1.5 ml-1">Nome Completo</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800 border border-[#e2e8ce] dark:border-gray-700 rounded-2xl dark:text-white outline-none focus:ring-2 focus:ring-[#c5a059]"
                placeholder="Ex: João da Silva"
              />
            </div>
          )}
          
          <div>
            <label className="block text-[10px] font-bold text-[#4b5335] dark:text-[#c5a059] uppercase mb-1.5 ml-1">E-mail de Acesso</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Ex: lucas@teen.com"
              className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800 border border-[#e2e8ce] dark:border-gray-700 rounded-2xl dark:text-white outline-none focus:ring-2 focus:ring-[#c5a059]"
            />
          </div>

          <div className="relative">
            <label className="block text-[10px] font-bold text-[#4b5335] dark:text-[#c5a059] uppercase mb-1.5 ml-1">Perfil de Acesso (RBAC)</label>
            <div className="relative">
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800 border border-[#e2e8ce] dark:border-gray-700 rounded-2xl dark:text-white outline-none focus:ring-2 focus:ring-[#c5a059] appearance-none cursor-pointer font-bold text-sm"
              >
                <option value="student">Aluno (Apenas Leitura)</option>
                <option value="mentor">Mentor (Upload de Mídia)</option>
                <option value="admin">Administrador (Gestão de Aulas)</option>
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-[#c5a059] pointer-events-none w-4 h-4" />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full py-4 bg-[#4b5335] text-white font-black rounded-2xl hover:bg-[#3a432b] transition-all shadow-xl flex items-center justify-center gap-2 mt-6"
          >
            <ShieldCheck className="w-5 h-5 text-[#c5a059]" />
            {isLogin ? 'ENTRAR NA ESCOLA' : 'CRIAR MINHA MATRÍCULA'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsLogin(!isLogin)} 
            className="text-sm text-[#4b5335] dark:text-gray-300 font-bold hover:underline"
          >
            {isLogin ? 'Novo por aqui? Cadastre sua matrícula' : 'Já é aluno? Entre no seu portal'}
          </button>
        </div>

        <div className="mt-8 p-5 bg-[#fcfbf7] dark:bg-zinc-900 rounded-2xl border border-[#e2e8ce] dark:border-gray-700 text-[10px]">
          <p className="font-black text-[#4b5335] dark:text-[#c5a059] mb-2 uppercase tracking-widest flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> Info de Permissões:
          </p>
          <div className="space-y-1 text-gray-500 dark:text-gray-400 font-medium">
            <p>• Admin: Pode criar/editar/excluir aulas fixas.</p>
            <p>• Mentor: Pode fazer upload de vídeos/podcasts.</p>
            <p>• Aluno: Pode apenas consumir e responder testes.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
