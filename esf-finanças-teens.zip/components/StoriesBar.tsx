
import React from 'react';
import { User, Story } from '../types';
import { Plus } from 'lucide-react';

interface StoriesBarProps {
  currentUser: User;
  stories: Story[];
  onStoryClick: (story: Story) => void;
  onAddStory: () => void;
}

const StoriesBar: React.FC<StoriesBarProps> = ({ currentUser, stories, onStoryClick, onAddStory }) => {
  return (
    <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 pt-2 px-1">
      {/* Botão de Adicionar Story */}
      <div className="flex flex-col items-center gap-1 min-w-[72px]">
        <div className="relative">
          <div className="w-16 h-16 rounded-full p-0.5 bg-gray-200 dark:bg-zinc-800">
            <img src={currentUser.avatar} className="w-full h-full rounded-full object-cover border-2 border-white dark:border-zinc-900" alt="Seu Story" />
          </div>
          <button 
            onClick={onAddStory}
            className="absolute bottom-0 right-0 bg-[#4b5335] text-white p-1 rounded-full border-2 border-white dark:border-zinc-900 shadow-lg hover:scale-110 transition-transform"
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>
        <span className="text-[10px] font-medium text-gray-500 dark:text-gray-400">Seu Story</span>
      </div>

      {/* Lista de Stories */}
      {stories.map((story) => (
        <div 
          key={story.id} 
          onClick={() => onStoryClick(story)}
          className="flex flex-col items-center gap-1 min-w-[72px] cursor-pointer group"
        >
          <div className={`w-16 h-16 rounded-full p-0.5 transition-transform group-active:scale-95 ${
            story.hasViewed 
              ? 'bg-gray-300 dark:bg-zinc-700' 
              : 'bg-gradient-to-tr from-[#c5a059] via-[#4b5335] to-[#c5a059]'
          }`}>
            <img 
              src={story.userAvatar} 
              className="w-full h-full rounded-full object-cover border-2 border-white dark:border-zinc-900" 
              alt={story.userName} 
            />
          </div>
          <span className="text-[10px] font-medium text-gray-700 dark:text-gray-300 truncate w-16 text-center">
            {story.userName.split(' ')[0]}
          </span>
        </div>
      ))}
    </div>
  );
};

export default StoriesBar;
