
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Lesson, User, MediaAsset } from '../types';
import { BookOpen, FileText, GraduationCap, ArrowRight, Loader2, Sparkles, HelpCircle, Layout, ChevronLeft, Library, PlusCircle, File, PlayCircle, Trophy, RotateCcw, Award, Send, Check, Trash2, Edit3, Video, Headphones, Play, CheckCircle2, AlertCircle, Upload, Image as ImageIcon, Music, Film, FileType, CheckCircle, Edit, ChevronDown } from 'lucide-react';
import { evaluatePracticeAnswer } from '../services/geminiService';

interface EducationSectionProps {
  currentUser: User;
  lessons: Lesson[];
  mediaAssets: MediaAsset[];
  onAddLesson: (lesson: Lesson) => void;
  onUpdateLesson: (lesson: Lesson) => void;
  onDeleteLesson: (lessonId: string) => void;
  onAddMedia: (asset: MediaAsset) => void;
  onDeleteMedia: (assetId: string) => void;
  onEditLesson?: (lesson: Lesson) => void;
  onCompleteTest: (lessonId: string, score: number, responses: Record<number, number>) => void;
  onCompletePractice: (lessonId: string, averageScore: number, exercises: { answer: string; score: number; feedback: string }[]) => void;
  onCompleteArticle: (lessonId: string) => void;
  isDarkMode: boolean;
  activeTab: 'library' | 'create' | 'podcasts' | 'videos';
  setActiveTab: (tab: 'library' | 'create' | 'podcasts' | 'videos') => void;
  onOpenCreateModal?: () => void;
}

const EducationSection: React.FC<EducationSectionProps> = ({ 
  currentUser, 
  lessons, 
  mediaAssets,
  onDeleteLesson,
  onEditLesson,
  onAddMedia,
  onDeleteMedia,
  onCompleteTest,
  onCompletePractice,
  onCompleteArticle,
  isDarkMode, 
  activeTab, 
  setActiveTab,
  onOpenCreateModal
}) => {
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [activeLessonTab, setActiveLessonTab] = useState<'summary' | 'exercises' | 'tests' | 'article'>('summary');
  
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [testChoices, setTestChoices] = useState<Record<number, number>>({});
  const [testSubmitted, setTestSubmitted] = useState(false);
  const [showScoreModal, setShowScoreModal] = useState(false);

  const [currentExerciseIdx, setCurrentExerciseIdx] = useState(0);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [practiceResults, setPracticeResults] = useState<{ answer: string; score: number; feedback: string }[]>([]);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const selectedLesson = useMemo(() => 
    lessons.find(l => l.id === selectedLessonId) || null, 
    [lessons, selectedLessonId]
  );

  const isAdmin = currentUser.role === 'admin';
  const isMentor = currentUser.role === 'mentor';

  const filteredAssets = useMemo(() => {
    if (activeTab === 'podcasts') return mediaAssets.filter(a => a.type === 'audio');
    if (activeTab === 'videos') return mediaAssets.filter(a => a.type === 'video');
    if (activeTab === 'create') return mediaAssets.filter(a => a.type === 'pdf' || a.type === 'image');
    return [];
  }, [mediaAssets, activeTab]);

  const globalProgress = useMemo(() => {
    if (lessons.length === 0) return 0;
    const total = lessons.length * 3;
    let count = 0;
    lessons.forEach(l => {
      if (currentUser.completedTests?.[l.id]) count++;
      if (currentUser.completedPractices?.[l.id]) count++;
      if (currentUser.completedArticles?.[l.id]) count++;
    });
    return Math.round((count / total) * 100);
  }, [lessons, currentUser]);

  useEffect(() => {
    setTestChoices({});
    setTestSubmitted(false);
    setShowScoreModal(false);
    setCurrentExerciseIdx(0);
    setPracticeResults([]);
    if (selectedLesson && currentUser.completedTests?.[selectedLesson.id]) {
        setTestChoices(currentUser.completedTests[selectedLesson.id].responses);
        setTestSubmitted(true);
    }
  }, [selectedLessonId, currentUser]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const MAX_SIZE = 50 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      alert("Arquivo muito grande! O limite é de 50MB.");
      e.target.value = '';
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);
    setUploadSuccess(false);

    const reader = new FileReader();
    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const progress = Math.round((event.loaded / event.total) * 100);
        setUploadProgress(progress);
      }
    };

    reader.onloadend = () => {
      try {
        const base64 = reader.result as string;
        let type: MediaAsset['type'] = 'pdf';
        if (file.type.includes('audio')) type = 'audio';
        else if (file.type.includes('video')) type = 'video';
        else if (file.type.includes('image')) type = 'image';

        const newAsset: MediaAsset = {
          id: Math.random().toString(36).substr(2, 9),
          userId: currentUser.id,
          type,
          name: file.name,
          url: base64,
          mimeType: file.type,
          timestamp: Date.now()
        };

        onAddMedia(newAsset);
        setUploadProgress(100);
        setUploadSuccess(true);
        setIsUploading(false);
        setTimeout(() => setUploadSuccess(false), 3000);
      } catch (err) {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleFinishTest = () => {
    if (!selectedLesson) return;
    const totalQuestions = selectedLesson.tests.length;
    let correctOnes = 0;
    selectedLesson.tests.forEach((q, idx) => {
      if (testChoices[idx] === q.correctIndex) correctOnes++;
    });
    const finalScore = Math.round((correctOnes / totalQuestions) * 100);
    onCompleteTest(selectedLesson.id, finalScore, testChoices);
    setTestSubmitted(true);
    setShowScoreModal(true);
  };

  const handleSendPractice = useCallback(async () => {
    if (!selectedLesson) return;
    setIsEvaluating(true);
    try {
      const ex = selectedLesson.exercises[currentExerciseIdx];
      const result = await evaluatePracticeAnswer(ex.scenario, ex.instructions, currentAnswer);
      const updated = [...practiceResults, { answer: currentAnswer, ...result }];
      if (currentExerciseIdx < 2) {
        setPracticeResults(updated);
        setCurrentExerciseIdx(prev => prev + 1);
        setCurrentAnswer('');
      } else {
        const avg = Math.round(updated.reduce((a, b) => a + b.score, 0) / 3);
        onCompletePractice(selectedLesson.id, avg, updated);
        setSelectedLessonId(null);
        alert("Prática concluída!");
      }
    } catch (e) {
      alert("Erro na avaliação.");
    } finally {
      setIsEvaluating(false);
    }
  }, [selectedLesson, currentExerciseIdx, currentAnswer, practiceResults, onCompletePractice]);

  const renderAssetList = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
      {filteredAssets.map(asset => (
        <div key={asset.id} className="bg-[#121212] rounded-3xl border border-white/5 overflow-hidden group shadow-xl transition-all hover:scale-[1.02]">
          <div className="aspect-video bg-zinc-900 relative flex items-center justify-center overflow-hidden">
             {asset.type === 'image' && <img src={asset.url} className="w-full h-full object-cover" alt={asset.name} />}
             {asset.type === 'video' && <video src={asset.url} className="w-full h-full object-cover" controls />}
             {asset.type === 'audio' && <div className="w-20 h-20 bg-[#c5a059] rounded-full flex items-center justify-center text-black shadow-lg"><Music size={32} /></div>}
             {asset.type === 'pdf' && <div className="w-20 h-20 bg-zinc-800 rounded-[2rem] flex items-center justify-center text-[#c5a059]"><FileText size={32} /></div>}
             {(isAdmin || isMentor) && (
               <button onClick={() => onDeleteMedia(asset.id)} className="absolute top-3 right-3 p-2 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500"><Trash2 size={14} /></button>
             )}
          </div>
          <div className="p-5">
            <h5 className="text-white font-bold text-sm truncate mb-1">{asset.name}</h5>
            <div className="flex justify-between items-center">
               <span className="text-[9px] font-black text-[#c5a059] uppercase tracking-widest">{asset.type}</span>
               <span className="text-[9px] text-zinc-600 font-bold">{new Date(asset.timestamp).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  if (selectedLesson) {
    const testData = currentUser.completedTests?.[selectedLesson.id];
    const hasRead = !!currentUser.completedArticles?.[selectedLesson.id];
    const hasDonePractice = !!currentUser.completedPractices?.[selectedLesson.id];

    return (
      <div className="animate-in fade-in duration-500 pb-24">
        {showScoreModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-xl">
            <div className="bg-white dark:bg-[#1e1e1e] rounded-[3rem] w-full max-sm p-10 text-center space-y-8 animate-in zoom-in duration-300 border border-[#c5a059]/30 shadow-2xl">
              <div className="w-24 h-24 bg-gradient-to-tr from-[#4a5d23] to-[#c5a059] rounded-full flex items-center justify-center mx-auto shadow-xl"><Trophy className="text-white w-12 h-12" /></div>
              <div>
                <h3 className="text-3xl font-black dark:text-white tracking-tighter mb-2">Teste Concluído!</h3>
                <div className="mt-4 inline-block px-6 py-2 bg-[#c5a059]/10 border border-[#c5a059]/30 rounded-full text-[#c5a059] font-black text-2xl">{testData?.score || 0}%</div>
              </div>
              <button onClick={() => setShowScoreModal(false)} className="w-full py-5 bg-[#4a5d23] text-white font-black uppercase text-xs tracking-widest rounded-3xl shadow-xl hover:scale-105 transition-all">Continuar Estudando</button>
            </div>
          </div>
        )}

        <button onClick={() => setSelectedLessonId(null)} className="flex items-center gap-2 text-[#c5a059] font-black uppercase text-[10px] tracking-widest mb-6 hover:translate-x-[-4px] transition-transform"><ChevronLeft size={18} /> Voltar para Biblioteca</button>

        <div className="bg-[#121212] rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-12 bg-gradient-to-br from-[#4a5d23] to-[#c5a059]/10 flex justify-between items-start">
            <div>
              <h2 className="text-4xl font-black text-white tracking-tighter mb-4">{selectedLesson.title}</h2>
              <div className="flex gap-2">{selectedLesson.sources.map(s => <span key={s.id} className="bg-white/5 px-3 py-1 rounded-xl text-[9px] font-bold text-white/50 border border-white/10 uppercase">{s.type}</span>)}</div>
            </div>
            {isAdmin && (
              <div className="flex gap-2">
                <button onClick={() => onEditLesson?.(selectedLesson)} className="p-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-all border border-white/10" title="Editar Aula"><Edit size={20}/></button>
                <button onClick={() => { onDeleteLesson(selectedLesson.id); setSelectedLessonId(null); }} className="p-3 bg-red-500/10 rounded-full text-red-500 hover:bg-red-500/20 transition-all border border-red-500/20" title="Excluir Aula Fixa"><Trash2 size={20}/></button>
              </div>
            )}
          </div>

          <div className="flex border-b border-white/5 bg-zinc-900/40 overflow-x-auto no-scrollbar">
            {[ { id: 'summary', label: 'Resumo', icon: Layout }, { id: 'exercises', label: 'Prática', icon: Sparkles }, { id: 'tests', label: 'Testes', icon: HelpCircle }, { id: 'article', label: 'Artigo', icon: FileText }].map(tab => (
              <button key={tab.id} onClick={() => setActiveLessonTab(tab.id as any)} className={`flex-1 min-w-[100px] py-4 flex flex-col items-center gap-1 transition-all ${activeLessonTab === tab.id ? 'bg-zinc-800 text-[#c5a059]' : 'text-zinc-500'}`}><tab.icon className="w-5 h-5" /><span className="text-[9px] font-black uppercase">{tab.label}</span></button>
            ))}
          </div>

          <div className="p-10 min-h-[400px]">
             {activeLessonTab === 'summary' && <div className="text-zinc-300 text-xl leading-relaxed whitespace-pre-wrap">{selectedLesson.summary}</div>}
             {activeLessonTab === 'exercises' && (
                <div className="space-y-6">
                    {hasDonePractice ? (
                    <div className="p-12 bg-emerald-500/10 border border-emerald-500/20 rounded-[2.5rem] text-center space-y-4">
                        <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-lg text-white"><CheckCircle2 size={40}/></div>
                        <h4 className="text-white font-black text-2xl tracking-tighter">Prática Concluída!</h4>
                    </div>
                    ) : (
                    <>
                        <div className="p-8 bg-zinc-800/30 rounded-[2rem] border border-white/5">
                            <p className="font-bold text-2xl text-white mb-4">{selectedLesson.exercises[currentExerciseIdx].scenario}</p>
                            <p className="text-zinc-400 italic leading-relaxed">{selectedLesson.exercises[currentExerciseIdx].instructions}</p>
                        </div>
                        <textarea value={currentAnswer} onChange={(e) => setCurrentAnswer(e.target.value)} placeholder="Sua aplicação prática..." className="w-full h-48 bg-black/40 border border-white/10 rounded-[2rem] p-8 text-zinc-300 outline-none focus:ring-2 focus:ring-[#c5a059]/30 transition-all resize-none shadow-inner" />
                        <button onClick={handleSendPractice} disabled={isEvaluating || currentAnswer.length < 20} className="w-full py-5 bg-[#c5a059] text-black font-black uppercase text-xs tracking-widest rounded-3xl shadow-xl flex items-center justify-center gap-3 disabled:opacity-50 transition-all">
                            {isEvaluating ? <Loader2 className="animate-spin" /> : <><Send size={18} /> Enviar Resposta</>}
                        </button>
                    </>
                    )}
                </div>
             )}

             {activeLessonTab === 'tests' && (
                <div className="space-y-12 pb-10">
                   <div className="grid gap-8">
                     {selectedLesson.tests.map((q, idx) => (
                       <div key={idx} className="space-y-4">
                         <p className="text-white font-bold">{idx + 1}. {q.question}</p>
                         <div className="grid gap-2 pl-4">
                           {q.options.map((opt, oIdx) => {
                             const isSelected = testChoices[idx] === oIdx;
                             const isCorrect = q.correctIndex === oIdx;
                             let style = "bg-white/5 border-white/5 text-zinc-400";
                             if (testSubmitted) {
                               if (isCorrect) style = "bg-emerald-500/20 border-emerald-500 text-emerald-400";
                               else if (isSelected) style = "bg-red-500/20 border-red-500 text-red-400";
                             } else if (isSelected) style = "bg-[#c5a059]/20 border-[#c5a059] text-white";
                             return <button key={oIdx} disabled={testSubmitted} onClick={() => setTestChoices(p => ({ ...p, [idx]: oIdx }))} className={`w-full p-4 text-left rounded-xl border transition-all text-xs ${style}`}>{opt}</button>;
                           })}
                         </div>
                       </div>
                     ))}
                   </div>
                   {!testSubmitted && <button disabled={Object.keys(testChoices).length < 10} onClick={handleFinishTest} className="w-full py-6 bg-[#c5a059] text-black font-black uppercase tracking-widest rounded-3xl shadow-2xl disabled:opacity-30">Finalizar Teste e Receber Nota</button>}
                </div>
             )}

             {activeLessonTab === 'article' && (
                <div className="space-y-8">
                  <div className="text-zinc-400 leading-relaxed text-lg whitespace-pre-wrap">{selectedLesson.article}</div>
                  {!hasRead ? (
                    <button onClick={() => onCompleteArticle(selectedLesson.id)} className="w-full py-5 bg-[#4b5335] text-[#c5a059] border border-[#c5a059]/30 rounded-3xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-3 hover:bg-[#c5a059] hover:text-black transition-all shadow-xl"><CheckCircle size={20} /> Confirmar Leitura</button>
                  ) : (
                    <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 p-6 rounded-3xl text-emerald-500">
                      <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white"><CheckCircle size={20} /></div>
                      <div>
                        <h4 className="font-black text-sm uppercase tracking-tighter">Leitura Concluída</h4>
                      </div>
                    </div>
                  )}
                </div>
             )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <h2 className={`text-5xl font-black tracking-tighter ${isDarkMode ? 'text-white' : 'text-[#4b5335]'}`}>Biblioteca ESF</h2>
          <div className="w-full max-w-sm space-y-2">
            <div className="flex justify-between items-end"><span className="text-[10px] font-black text-[#c5a059] uppercase tracking-widest">Progresso no Curso</span><span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#c5a059] text-black">{globalProgress}%</span></div>
            <div className="h-2 bg-black/20 rounded-full overflow-hidden border border-white/5"><div className="h-full bg-gradient-to-r from-[#4b5335] to-[#c5a059] transition-all duration-1000" style={{ width: `${globalProgress}%` }} /></div>
          </div>
        </div>

        <div className="flex p-1.5 bg-black/20 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar gap-1">
          {[ 
            { id: 'library', label: 'Estante', icon: Library }, 
            { id: 'podcasts', label: 'Podcasts', icon: Headphones }, 
            { id: 'videos', label: 'Vídeos', icon: Video },
            ...(isAdmin ? [{ id: 'create', label: 'Novo', icon: FileType }] : [])
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-[#c5a059] text-black shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}><tab.icon size={14}/> {tab.label}</button>
          ))}
        </div>
      </div>

      <div className="space-y-8">
        <div className="flex flex-col bg-[#121212] rounded-[2.5rem] border border-white/5 shadow-2xl overflow-hidden">
           <div className="flex items-center justify-between p-8">
              <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-[#c5a059]/10 rounded-2xl flex items-center justify-center text-[#c5a059]">{activeTab === 'library' ? <BookOpen size={24}/> : <FileType size={24}/>}</div>
                  <div>
                    <h4 className="text-white font-black text-xl tracking-tighter uppercase">{activeTab === 'library' ? 'Aulas Fixas' : 'Meus Arquivos'}</h4>
                  </div>
              </div>
              <div className="flex gap-3">
                {activeTab === 'library' ? (
                  isAdmin && (
                    <button onClick={onOpenCreateModal} className="px-6 py-3 bg-[#c5a059] text-black font-black uppercase text-[10px] rounded-xl flex items-center gap-2 shadow-lg hover:scale-105 transition-all"><Sparkles size={14} /> Criar Aula IA</button>
                  )
                ) : (
                   (isAdmin || isMentor) && (
                    <button onClick={() => !isUploading && fileInputRef.current?.click()} className="px-6 py-3 bg-[#c5a059] text-black font-black uppercase text-[10px] rounded-xl flex items-center gap-2 shadow-lg transition-all"><Upload size={14} /> Upload</button>
                   )
                )}
              </div>
           </div>
        </div>

        {activeTab === 'library' ? (
           <div className="grid gap-4">
             {lessons.map(lesson => {
                const hasRead = !!currentUser.completedArticles?.[lesson.id];
                const hasTest = !!currentUser.completedTests?.[lesson.id];
                const hasPractice = !!currentUser.completedPractices?.[lesson.id];
                const allDone = hasRead && hasTest && hasPractice;
                return (
                    <div key={lesson.id} className="group relative">
                      {isAdmin && (
                        <div className="flex items-center gap-2 absolute right-6 top-1/2 -translate-y-1/2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={(e) => { e.stopPropagation(); onEditLesson?.(lesson); }} 
                              className="p-3 bg-zinc-800 text-[#c5a059] hover:bg-[#c5a059] hover:text-black rounded-full transition-all border border-white/10 shadow-lg"
                              title="Editar Estrutura"
                            >
                              <Edit size={16}/>
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); onDeleteLesson(lesson.id); }} 
                              className="p-3 bg-zinc-800 text-red-500 hover:bg-red-500 hover:text-white rounded-full transition-all border border-red-500/20 shadow-lg"
                              title="Excluir Aula Fixa"
                            >
                              <Trash2 size={16}/>
                            </button>
                        </div>
                      )}
                      <div onClick={() => setSelectedLessonId(lesson.id)} className={`p-6 bg-[#121212] rounded-[2.5rem] border border-white/5 hover:border-[#c5a059]/30 transition-all cursor-pointer flex items-center justify-between ${isAdmin ? 'group-hover:pr-32' : ''}`}>
                        <div className="flex items-center gap-6">
                            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all ${allDone ? 'bg-[#c5a059] text-black shadow-lg scale-105' : 'bg-zinc-900 text-[#c5a059] border border-white/5'}`}>{allDone ? <Trophy size={24} /> : <BookOpen size={24} />}</div>
                            <div>
                                <h4 className="font-black text-2xl text-white tracking-tighter">{lesson.title}</h4>
                                <div className="flex gap-3 mt-1.5">
                                   <div className={`flex items-center gap-1 text-[8px] font-black uppercase tracking-widest ${hasRead ? 'text-[#c5a059]' : 'text-zinc-600'}`}><BookOpen size={10} /> Artigo</div>
                                   <div className={`flex items-center gap-1 text-[8px] font-black uppercase tracking-widest ${hasTest ? 'text-emerald-500' : 'text-zinc-600'}`}><HelpCircle size={10} /> Teste</div>
                                   <div className={`flex items-center gap-1 text-[8px] font-black uppercase tracking-widest ${hasPractice ? 'text-emerald-500' : 'text-zinc-600'}`}><Sparkles size={10} /> Prática</div>
                                </div>
                            </div>
                        </div>
                        <ArrowRight className="text-zinc-800 group-hover:text-[#c5a059] transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                );
             })}
           </div>
        ) : renderAssetList()}
      </div>

      <input type="file" ref={fileInputRef} hidden onChange={handleFileUpload} accept={activeTab === 'podcasts' ? 'audio/*' : activeTab === 'videos' ? 'video/*' : 'application/pdf,image/*'} />
    </div>
  );
};

export default EducationSection;
