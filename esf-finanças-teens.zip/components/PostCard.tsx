
import React, { useState, useEffect, useRef } from 'react';
import { Post, User } from '../types';
import { Heart, MessageCircle, Share2, MoreHorizontal, Play, Music, FileText, Trash2, Clock, Sparkles, Volume2, ChevronLeft, ChevronRight, Eye, ExternalLink, Loader2 } from 'lucide-react';

interface PostCardProps {
  post: Post;
  currentUser: User | null;
  onLike: (postId: string) => void;
  onComment: (postId: string, text: string) => void;
  onDelete?: (postId: string) => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, currentUser, onLike, onComment, onDelete }) => {
  const [commentText, setCommentText] = useState('');
  const [showComments, setShowComments] = useState(false);
  const [loadMedia, setLoadMedia] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [localViews, setLocalViews] = useState(post.views);
  const [isVisible, setIsVisible] = useState(false);
  const [isMediaLoaded, setIsMediaLoaded] = useState(false);
  const [showNewBanner, setShowNewBanner] = useState(() => {
    return (Date.now() - post.timestamp) < 10000;
  });

  const cardRef = useRef<HTMLDivElement>(null);
  const contentArray = Array.isArray(post.content) ? post.content : [post.content];

  // Intersection Observer para Lazy Loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // Uma vez visível, não precisamos mais observar
        }
      },
      { threshold: 0.1, rootMargin: '100px' } // Carrega 100px antes de entrar na tela
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (showNewBanner) {
      const timer = setTimeout(() => {
        setShowNewBanner(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showNewBanner]);

  useEffect(() => {
    if (isVisible && (loadMedia || (post.type === 'image'))) {
      setLocalViews(prev => prev + 1);
    }
  }, [isVisible, loadMedia, post.type]);

  const isLiked = currentUser ? post.likes.includes(currentUser.id) : false;
  const canDelete = currentUser?.role === 'admin' || currentUser?.id === post.userId;

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    onComment(post.id, commentText);
    setCommentText('');
  };

  const formatExactDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const nextSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlide((prev) => (prev + 1) % contentArray.length);
    setIsMediaLoaded(false);
  };

  const prevSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlide((prev) => (prev - 1 + contentArray.length) % contentArray.length);
    setIsMediaLoaded(false);
  };

  const renderPlaceholder = (icon: React.ReactNode) => (
    <div className="aspect-video w-full bg-zinc-900 flex flex-col items-center justify-center gap-4 animate-pulse">
      <div className="text-zinc-800">{icon}</div>
      <div className="h-2 w-32 bg-zinc-800 rounded-full" />
    </div>
  );

  const renderContent = () => {
    if (!isVisible) {
      return renderPlaceholder(<Sparkles size={48} />);
    }

    switch (post.type) {
      case 'image':
        return (
          <div className="relative group overflow-hidden bg-black flex items-center justify-center min-h-[300px]">
            {!isMediaLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-zinc-900 z-10">
                <Loader2 className="animate-spin text-[#c5a059]" />
              </div>
            )}
            <img 
              key={currentSlide}
              src={contentArray[currentSlide]} 
              alt={`${post.description} - slide ${currentSlide + 1}`} 
              onLoad={() => setIsMediaLoaded(true)}
              className={`w-full h-auto object-cover max-h-[600px] transition-opacity duration-700 ${isMediaLoaded ? 'opacity-100' : 'opacity-0'}`} 
            />
            {contentArray.length > 1 && (
              <>
                <button onClick={prevSlide} className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-black/30 backdrop-blur-md rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity z-20"><ChevronLeft className="w-6 h-6" /></button>
                <button onClick={nextSlide} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-black/30 backdrop-blur-md rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity z-20"><ChevronRight className="w-6 h-6" /></button>
                <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] text-white font-bold z-20">{currentSlide + 1} / {contentArray.length}</div>
                <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5 z-20">{contentArray.map((_, i) => (<div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-4 bg-[#c5a059]' : 'w-1.5 bg-white/40'}`}/>))}</div>
              </>
            )}
          </div>
        );
      case 'video':
        if (!loadMedia) {
          return (
            <div onClick={() => setLoadMedia(true)} className="relative aspect-video bg-zinc-900 cursor-pointer group overflow-hidden">
              {post.thumbnail ? <img src={post.thumbnail} alt="Preview" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" /> : <div className="absolute inset-0 bg-gradient-to-br from-[#4b5335] to-[#c5a059] opacity-40" />}
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3"><div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center group-hover:scale-110 transition-transform border border-white/30"><Play className="text-white w-8 h-8 fill-current ml-1" /></div><span className="text-white text-[10px] font-bold uppercase tracking-[0.2em] drop-shadow-md">Clique para assistir</span></div>
            </div>
          );
        }
        return <div className="relative aspect-video bg-black flex items-center justify-center animate-in fade-in duration-300"><video src={contentArray[0]} autoPlay controls className="w-full h-full" /></div>;
      case 'audio':
        if (!loadMedia) {
          return (
            <div onClick={() => setLoadMedia(true)} className="p-8 bg-gradient-to-br from-[#fcfbf7] to-[#f5f5f0] dark:from-zinc-800 dark:to-zinc-900 flex flex-col items-center gap-4 cursor-pointer group border-y border-[#e2e8ce] dark:border-gray-800">
              <div className="relative"><div className="w-20 h-20 bg-[#4a5d23] rounded-full flex items-center justify-center text-[#c5a059] group-hover:rotate-12 transition-transform shadow-lg"><Music className="w-10 h-10" /></div><div className="absolute -bottom-1 -right-1 bg-[#c5a059] p-1.5 rounded-full text-white shadow-md"><Play className="w-3 h-3 fill-current" /></div></div>
              <div className="text-center"><p className="text-sm font-bold text-[#4a5d23] dark:text-[#c5a059] mb-1">{post.title || "Finanças em Áudio"}</p><p className="text-[10px] text-gray-400 uppercase tracking-widest">Escutar ensinamento</p></div>
            </div>
          );
        }
        return <div className="p-6 bg-[#fcfbf7] dark:bg-zinc-900 border-y border-[#e2e8ce] dark:border-gray-800 animate-in slide-in-from-top-2"><div className="flex items-center gap-3 mb-4"><div className="w-10 h-10 bg-[#4a5d23] rounded-lg flex items-center justify-center text-[#c5a059]"><Volume2 className="w-6 h-6 animate-pulse" /></div><div><p className="text-xs font-bold dark:text-white uppercase tracking-tighter">{post.title || "Áudio ESF"}</p><p className="text-[10px] text-[#c5a059] font-medium">Reproduzindo agora...</p></div></div><audio src={contentArray[0]} autoPlay controls className="w-full accent-[#4a5d23]" /></div>;
      case 'article':
        return <div className="p-6 bg-white dark:bg-zinc-900 border-y border-[#e2e8ce] dark:border-gray-800"><div className="flex items-center gap-2 mb-3 text-[#4a5d23]"><FileText className="w-5 h-5 text-[#c5a059]" /><h3 className="font-bold text-lg dark:text-slate-100">{post.title || 'Artigo Educativo'}</h3></div><p className="text-gray-700 dark:text-slate-400 leading-relaxed line-clamp-4">{contentArray[0]}</p><button className="mt-2 text-[#c5a059] text-sm font-semibold hover:underline">Ler mais...</button></div>;
      default:
        return null;
    }
  };

  return (
    <div ref={cardRef} className={`rounded-xl shadow-sm border mb-6 overflow-hidden relative transition-all duration-300 ${showNewBanner ? 'ring-2 ring-[#c5a059]' : ''} bg-white dark:bg-[#1e1e1e] border-[#e2e8ce] dark:border-gray-800 min-h-[200px]`}>
      <div className={`bg-gradient-to-r from-[#4b5335] to-[#c5a059] text-white text-[10px] font-bold py-1.5 px-4 flex items-center justify-center gap-2 transition-all duration-500 overflow-hidden ${showNewBanner ? 'h-8 opacity-100' : 'h-0 opacity-0'}`}><Sparkles className="w-3 h-3 text-[#c5a059]" /><span className="uppercase tracking-widest">Novo Conteúdo na ESF</span><Sparkles className="w-3 h-3 text-[#c5a059]" /></div>
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={post.userAvatar} alt={post.userName} className="w-10 h-10 rounded-full object-cover border border-[#e2e8ce] dark:border-gray-700" />
          <div className="flex flex-col">
            <div className="flex items-center gap-2"><p className="font-bold text-sm text-gray-800 dark:text-slate-100">{post.userName}</p><span className="text-gray-300 dark:text-gray-600 text-xs">•</span><div className="flex items-center gap-1 text-[10px] text-gray-400 font-medium"><Clock className="w-2.5 h-2.5" /><span>{formatExactDate(post.timestamp)}</span></div></div>
            <p className="text-[9px] text-[#c5a059] font-black uppercase tracking-widest leading-none mt-0.5">Membro ESF</p>
          </div>
        </div>
        <div className="flex items-center gap-1">{canDelete && <button onClick={() => onDelete?.(post.id)} className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 hover:text-red-600 transition-colors rounded-full" title="Excluir postagem"><Trash2 className="w-4 h-4" /></button>}<button className="p-2 hover:bg-gray-50 dark:hover:bg-zinc-800 text-gray-400 rounded-full"><MoreHorizontal className="w-5 h-5" /></button></div>
      </div>
      {renderContent()}
      <div className={`px-4 py-2 border-b flex items-center gap-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider transition-colors ${post.type === 'image' || post.type === 'video' ? 'bg-zinc-50 dark:bg-zinc-800/50' : 'bg-[#fcfbf7]/50 dark:bg-[#121212]/50'} border-[#fcfbf7] dark:border-gray-800`}>
        <span className="flex items-center gap-1 text-[#c5a059]"><Heart className="w-3 h-3 fill-current" />{post.likes.length} {post.likes.length === 1 ? 'curtida' : 'curtidas'}</span>
        <span className="w-1 h-1 bg-gray-300 dark:bg-gray-700 rounded-full"></span>
        <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3 fill-gray-300 dark:fill-gray-600" />{post.comments.length} {post.comments.length === 1 ? 'comentário' : 'comentários'}</span>
        {(post.type === 'image' || post.type === 'video') && <><span className="w-1 h-1 bg-gray-300 dark:bg-gray-700 rounded-full"></span><span className="flex items-center gap-1"><Eye className="w-3 h-3 text-gray-400" />{localViews} {localViews === 1 ? 'visualização' : 'visualizações'}</span></>}
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-4">
            <button onClick={() => onLike(post.id)} className={`flex items-center gap-1 transition-colors ${isLiked ? 'text-red-600' : 'text-gray-700 dark:text-gray-400 hover:text-[#4a5d23]'}`}><Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} /></button>
            <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-1 text-gray-700 dark:text-gray-400 hover:text-[#4a5d23]"><MessageCircle className="w-6 h-6" /></button>
            <button className="text-gray-700 dark:text-gray-400 hover:text-[#4a5d23]"><Share2 className="w-6 h-6" /></button>
          </div>
        </div>
        <div className="space-y-2">
          <p className="text-sm text-gray-800 dark:text-slate-200"><span className="font-bold mr-2">{post.userName}</span>{post.description}</p>
          
          {/* Link de Fonte */}
          {post.sourceUrl && (
            <a 
              href={post.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#c5a059]/10 hover:bg-[#c5a059]/20 border border-[#c5a059]/20 rounded-lg text-[10px] font-black text-[#c5a059] uppercase tracking-widest transition-all group"
            >
              <ExternalLink className="w-3 h-3 group-hover:scale-110 transition-transform" />
              Ver Fonte do Conteúdo
            </a>
          )}
        </div>
        {showComments && (
          <div className="mt-4 pt-4 border-t border-[#e2e8ce] dark:border-gray-800 space-y-3">
            {post.comments.map(comment => (<div key={comment.id} className="flex gap-2 text-sm"><span className="font-bold text-[#4a5d23] dark:text-[#c5a059]">{comment.userName}</span><span className="text-gray-700 dark:text-slate-400">{comment.text}</span></div>))}
            <form onSubmit={handleSubmitComment} className="flex gap-2 mt-4"><input type="text" value={commentText} onChange={(e) => setCommentText(e.target.value)} placeholder="Adicione um comentário..." className="flex-1 text-sm bg-gray-50 dark:bg-zinc-800 border border-[#e2e8ce] dark:border-gray-700 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#4a5d23] dark:text-slate-100" /><button type="submit" disabled={!commentText.trim()} className="text-[#4a5d23] dark:text-[#c5a059] font-bold text-sm disabled:opacity-50">Publicar</button></form>
          </div>
        )}
      </div>
    </div>
  );
};

export default PostCard;
