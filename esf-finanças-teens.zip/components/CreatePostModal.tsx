
import React, { useState, useRef, useEffect } from 'react';
import { ContentType, Lesson, SourceMaterial, User } from '../types';
import { X, Image as ImageIcon, Video, Mic, FileText, Loader2, CheckCircle, LayoutGrid, GraduationCap, AlertCircle, Trash2, Upload, RotateCcw } from 'lucide-react';
import { generateLessonContent } from '../services/geminiService';

interface CreatePostModalProps {
  onClose: () => void;
  onPost: (postData: { type: ContentType; content: string | string[]; description: string; title?: string }) => void;
  onPostLesson: (lesson: Lesson) => void;
  existingLesson?: Lesson;
  currentUser: User | null;
}

const DRAFT_KEY = 'esf_post_draft_v1';

const SUPPORTED_MIME_TYPES = [
  'image/png', 'image/jpeg', 'image/webp', 'image/heic', 'image/heif',
  'video/mp4', 'video/mpeg', 'video/mov', 'video/avi', 'video/x-flv', 'video/mpg', 'video/webm', 'video/wmv', 'video/3gpp',
  'audio/wav', 'audio/mp3', 'audio/aiff', 'audio/aac', 'audio/ogg', 'audio/flac',
  'application/pdf'
];

const CreatePostModal: React.FC<CreatePostModalProps> = ({ onClose, onPost, onPostLesson, existingLesson, currentUser }) => {
  const [target, setTarget] = useState<'feed' | 'education'>(existingLesson ? 'education' : 'feed');
  const [type, setType] = useState<ContentType>('image');
  const [description, setDescription] = useState('');
  const [title, setTitle] = useState(existingLesson ? existingLesson.title : '');
  const [contents, setContents] = useState<{ blob: string; file?: File; id: string }[]>([]);
  const [eduMaterials, setEduMaterials] = useState<SourceMaterial[]>(existingLesson ? existingLesson.sources : []);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasLoadedDraft, setHasLoadedDraft] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!existingLesson) {
      const savedDraft = localStorage.getItem(DRAFT_KEY);
      if (savedDraft) {
        try {
          const draft = JSON.parse(savedDraft);
          setTarget(draft.target || 'feed');
          setType(draft.type || 'image');
          setTitle(draft.title || '');
          setDescription(draft.description || '');
          setEduMaterials(draft.eduMaterials || []);
          setHasLoadedDraft(true);
        } catch (e) {}
      }
    }
  }, [existingLesson]);

  useEffect(() => {
    if (isGenerating || existingLesson) return;

    const draftData = {
      target,
      type,
      title,
      description,
      eduMaterials: eduMaterials.map(m => ({ ...m, content: m.content.substring(0, 500000) }))
    };

    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draftData));
    } catch (e) {}
  }, [target, type, title, description, eduMaterials, isGenerating, existingLesson]);

  const clearDraft = () => {
    if (isGenerating) return;
    localStorage.removeItem(DRAFT_KEY);
    setTarget('feed');
    setType('image');
    setTitle('');
    setDescription('');
    setEduMaterials([]);
    setContents([]);
    setHasLoadedDraft(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isGenerating) return;
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;

    if (target === 'education') {
      setError(null);
      files.forEach(file => {
        const mimeType = file.type || 'application/octet-stream';
        if (!SUPPORTED_MIME_TYPES.includes(mimeType)) {
          setError(`O arquivo "${file.name}" tem um formato não suportado pela IA.`);
          return;
        }

        let fType: SourceMaterial['type'] = 'pdf';
        if (mimeType.includes('image')) fType = 'image';
        else if (mimeType.includes('video')) fType = 'video';
        else if (mimeType.includes('audio')) fType = 'audio';
        else if (mimeType.includes('pdf')) fType = 'pdf';

        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = (reader.result as string).split(',')[1];
          const newMaterial: SourceMaterial = {
            id: Math.random().toString(36).substr(2, 9),
            type: fType,
            name: file.name,
            mimeType: mimeType,
            content: base64
          };
          setEduMaterials(prev => [...prev, newMaterial]);
        };
        reader.readAsDataURL(file);
      });
    } else {
      const newContents = files.map(file => ({
        blob: URL.createObjectURL(file),
        file: file,
        id: Math.random().toString(36).substr(2, 9)
      }));
      if (type === 'image') setContents(prev => [...prev, ...newContents]);
      else setContents(newContents.slice(0, 1));
    }
    e.target.value = '';
  };

  const handleSubmit = async () => {
    if (isGenerating || !currentUser) return;

    if (target === 'education') {
      if (!title.trim()) { setError("O título é obrigatório."); return; }
      if (eduMaterials.length === 0) { setError("Anexe materiais."); return; }
      
      setIsGenerating(true);
      setError(null);
      try {
        const result = await generateLessonContent(title, eduMaterials);
        const newLesson: Lesson = {
          id: existingLesson ? existingLesson.id : Math.random().toString(36).substr(2, 9),
          userId: existingLesson ? existingLesson.userId : currentUser.id,
          title,
          ...result,
          sources: eduMaterials,
          timestamp: existingLesson ? existingLesson.timestamp : Date.now()
        };
        onPostLesson(newLesson);
        localStorage.removeItem(DRAFT_KEY);
        onClose();
      } catch (err: any) {
        setError(`Erro: ${err.message}`);
        setIsGenerating(false);
      }
    } else {
      if (contents.length === 0 && type !== 'article') return;
      onPost({
        type,
        content: type === 'article' ? description : (contents.length > 1 ? contents.map(c => c.blob) : contents[0].blob),
        description: type === 'article' ? (title || "Post ESF") : description,
        title: type === 'article' ? title : undefined
      });
      localStorage.removeItem(DRAFT_KEY);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
      <div className="bg-white dark:bg-zinc-900 rounded-[3rem] w-full max-w-lg overflow-hidden shadow-2xl border border-white/5 animate-in zoom-in duration-300">
        <div className="p-8 border-b border-gray-100 dark:border-white/5 flex justify-between items-center bg-gray-50/30 dark:bg-zinc-800/30">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-black text-2xl text-[#4a5d23] dark:text-[#c5a059] tracking-tighter uppercase">
                {existingLesson ? 'Editar Aula' : 'Novo Conteúdo'}
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onClose} disabled={isGenerating} className="p-2 text-gray-400 hover:text-red-500 transition-colors"><X size={24} /></button>
          </div>
        </div>

        <div className={`p-8 space-y-6 max-h-[70vh] overflow-y-auto no-scrollbar ${isGenerating ? 'opacity-60 pointer-events-none' : ''}`}>
          <div className="flex p-1.5 bg-gray-100 dark:bg-zinc-800 rounded-2xl gap-1">
            <button disabled={!!existingLesson} onClick={() => setTarget('feed')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${target === 'feed' ? 'bg-[#2a2a2a] text-[#c5a059] shadow-lg' : 'text-gray-400'}`}><LayoutGrid size={14} /> Feed</button>
            <button disabled={!!existingLesson} onClick={() => setTarget('education')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${target === 'education' ? 'bg-[#2a2a2a] text-[#c5a059] shadow-lg' : 'text-gray-400'}`}><GraduationCap size={14} /> Aula</button>
          </div>

          <div className="space-y-4">
            <input type="text" placeholder={target === 'education' ? "Título da Aula" : "Título opcional"} value={title} disabled={isGenerating} onChange={(e) => setTitle(e.target.value)} className="w-full px-6 py-4 bg-gray-50 dark:bg-zinc-800 border border-gray-100 dark:border-white/10 rounded-2xl dark:text-white outline-none font-bold" />
            
            {((target === 'education' && eduMaterials.length > 0) || (target === 'feed' && contents.length > 0)) && (
              <div className="space-y-2 max-h-48 overflow-y-auto no-scrollbar">
                {target === 'education' && eduMaterials.map(m => (
                  <div key={m.id} className="flex items-center justify-between p-3 bg-emerald-50 dark:bg-emerald-900/10 rounded-xl border border-emerald-100 dark:border-emerald-900/30 group">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className="text-emerald-500">{m.type === 'image' && <ImageIcon size={14}/>}{m.type === 'video' && <Video size={14}/>}{m.type === 'audio' && <Mic size={14}/>}{m.type === 'pdf' && <FileText size={14}/>}</div>
                      <span className="text-xs font-bold dark:text-emerald-400 truncate w-40">{m.name}</span>
                    </div>
                    {!isGenerating && <button onClick={() => setEduMaterials(prev => prev.filter(i => i.id !== m.id))} className="text-red-400 p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full"><Trash2 size={14}/></button>}
                  </div>
                ))}
              </div>
            )}

            <div onClick={() => !isGenerating && fileInputRef.current?.click()} className={`py-12 border-2 border-dashed border-gray-200 dark:border-white/10 rounded-[2rem] flex flex-col items-center justify-center gap-2 text-gray-400 transition-all ${isGenerating ? 'cursor-not-allowed opacity-50' : 'hover:border-[#c5a059]/50 hover:bg-[#c5a059]/5 cursor-pointer'}`}>
              <Upload className="text-[#c5a059] w-8 h-8" />
              <p className="font-black uppercase text-[10px] tracking-widest">Anexar Materiais</p>
            </div>

            <textarea placeholder="Notas complementares..." value={description} disabled={isGenerating} onChange={(e) => setDescription(e.target.value)} className="w-full h-32 px-6 py-4 bg-gray-50 dark:bg-zinc-800 border border-gray-100 dark:border-white/10 rounded-2xl dark:text-white outline-none resize-none" />
          </div>

          {error && <div className="p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-2xl border border-red-100 dark:border-red-900/50 text-[10px] font-black uppercase flex items-center gap-3"><AlertCircle size={16} /><span>{error}</span></div>}
        </div>

        <div className="p-8 border-t border-gray-100 dark:border-white/5 flex gap-4 bg-gray-50/50 dark:bg-zinc-900/50">
          <button onClick={onClose} disabled={isGenerating} className="flex-1 py-4 font-black uppercase text-[10px] text-gray-500">Sair</button>
          <button onClick={handleSubmit} disabled={isGenerating} className="flex-1 py-4 bg-[#4a5d23] text-white rounded-2xl font-black shadow-xl uppercase text-[10px] flex items-center justify-center gap-2">
            {isGenerating ? <><Loader2 className="animate-spin w-4 h-4" /><span>Processando...</span></> : <><CheckCircle size={16} /><span>Finalizar</span></>}
          </button>
        </div>
      </div>
      <input 
        type="file" 
        ref={fileInputRef} 
        hidden 
        onChange={handleFileChange} 
        multiple 
        accept={target === 'education' ? SUPPORTED_MIME_TYPES.join(',') : 'image/*,video/*,audio/*'}
      />
    </div>
  );
};

export default CreatePostModal;
