
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, Loader2, Bot } from 'lucide-react';
import { chatWithMentor } from '../services/geminiService';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Olá, sou o seu Mentor Sábio. Como posso ajudar na sua jornada financeira hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const response = await chatWithMentor(userMsg, history);
    setMessages(prev => [...prev, { role: 'model', text: response || 'Houve um lapso na sabedoria, tente novamente.' }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-24 right-6 z-[100]">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-[#c5a059] rounded-full shadow-2xl flex items-center justify-center text-white hover:scale-110 transition-all border-4 border-white dark:border-[#0a0a0a] animate-bounce"
        >
          <Bot size={32} />
        </button>
      ) : (
        <div className="w-[90vw] sm:w-[400px] h-[500px] bg-white dark:bg-[#121212] rounded-[2.5rem] shadow-[0_20px_60px_rgba(0,0,0,0.4)] border border-[#c5a059]/30 flex flex-col overflow-hidden animate-in zoom-in duration-300">
          {/* Header */}
          <div className="p-6 bg-gradient-to-r from-[#4b5335] to-[#c5a059] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white backdrop-blur-md">
                <Sparkles size={20} />
              </div>
              <div>
                <h3 className="text-white font-black text-sm uppercase tracking-tighter">Mentor Sábio IA</h3>
                <p className="text-white/70 text-[8px] font-bold uppercase tracking-widest">Online agora</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white hover:rotate-90 transition-transform">
              <X size={24} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar bg-[#fcfbf7] dark:bg-[#0a0a0a]">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-4 rounded-2xl text-xs leading-relaxed shadow-sm ${
                  m.role === 'user' 
                    ? 'bg-[#4b5335] text-white rounded-tr-none' 
                    : 'bg-white dark:bg-zinc-800 text-gray-800 dark:text-zinc-200 border border-gray-100 dark:border-white/5 rounded-tl-none'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-2xl rounded-tl-none border border-gray-100 dark:border-white/5">
                  <Loader2 className="animate-spin text-[#c5a059]" size={16} />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <form onSubmit={handleSend} className="p-4 bg-white dark:bg-zinc-900 border-t dark:border-white/5 flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pergunte sobre finanças..."
              className="flex-1 bg-gray-100 dark:bg-zinc-800 border-none rounded-full px-5 py-3 text-xs outline-none focus:ring-2 focus:ring-[#c5a059]/30 dark:text-white"
            />
            <button 
              type="submit"
              disabled={isLoading || !input.trim()}
              className="w-11 h-11 bg-[#c5a059] text-white rounded-full flex items-center justify-center hover:scale-105 transition-transform disabled:opacity-50"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ChatBot;
