
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { X, Mic, MicOff, Camera, Video, VideoOff, Users, Send, MessageCircle, Heart, Sparkles, Smile } from 'lucide-react';

interface LiveSessionProps {
  onClose: () => void;
  isDarkMode: boolean;
}

interface Reaction {
  id: number;
  emoji: string;
  left: number;
}

const LiveSession: React.FC<LiveSessionProps> = ({ onClose, isDarkMode }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState<{ id: string; role: string; text: string }[]>([]);
  const [spectators, setSpectators] = useState(Math.floor(Math.random() * 50) + 85);
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [chatMessage, setChatMessage] = useState('');
  const [isMentorSpeaking, setIsMentorSpeaking] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const frameIntervalRef = useRef<number | null>(null);
  const sessionRef = useRef<any>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Helper functions for audio encoding/decoding
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const addReaction = () => {
    const emojis = ['❤️', '💎', '🚀', '📈', '🔥', '👏'];
    const newReaction = {
      id: Date.now(),
      emoji: emojis[Math.floor(Math.random() * emojis.length)],
      left: Math.random() * 80 + 10,
    };
    setReactions(prev => [...prev, newReaction]);
    setTimeout(() => {
      setReactions(prev => prev.filter(r => r.id !== newReaction.id));
    }, 3000);
  };

  const sendChatMessage = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!chatMessage.trim() || !sessionRef.current) return;
    
    // Simula envio para o Mentor
    const msg = { id: Math.random().toString(), role: 'Você', text: chatMessage };
    setTranscription(prev => [...prev, msg]);
    
    // O Gemini Live API processa áudio principalmente, mas podemos enviar texto via partes se o SDK permitir
    // Como estamos usando a interface de realtime input de áudio/imagem, 
    // tratamos o chat como uma interação visual que o mentor pode "ver" se capturarmos o frame.
    
    setChatMessage('');
  };

  const startLive = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: { width: 1280, height: 720, facingMode: 'user' } 
      });
      if (videoRef.current) videoRef.current.srcObject = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: 'Você é o Mentor Sábio da ESF Finanças Teens. Você está em uma live no Instagram com alunos. Seja encorajador, use referências bíblicas quando apropriado e responda de forma concisa. Você pode ver o que o aluno mostra na câmera.',
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        },
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);

            frameIntervalRef.current = window.setInterval(() => {
              if (videoRef.current && canvasRef.current) {
                const ctx = canvasRef.current.getContext('2d');
                ctx?.drawImage(videoRef.current, 0, 0, 320, 240);
                canvasRef.current.toBlob(async (blob) => {
                  if (blob) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      const base64 = (reader.result as string).split(',')[1];
                      sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64, mimeType: 'image/jpeg' } }));
                    };
                    reader.readAsDataURL(blob);
                  }
                }, 'image/jpeg', 0.5);
              }
            }, 1000);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outAudioContextRef.current) {
              setIsMentorSpeaking(true);
              const audioBuffer = await decodeAudioData(decode(audioData), outAudioContextRef.current, 24000, 1);
              const source = outAudioContextRef.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outAudioContextRef.current.destination);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outAudioContextRef.current.currentTime);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsMentorSpeaking(false);
              };
            }

            if (message.serverContent?.inputTranscription) {
              setTranscription(prev => [...prev, { id: Math.random().toString(), role: 'Você', text: message.serverContent!.inputTranscription!.text }]);
            }
            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => [...prev, { id: Math.random().toString(), role: 'Mentor', text: message.serverContent!.outputTranscription!.text }]);
              if (Math.random() > 0.7) addReaction(); // Mentor causa reações automáticas!
            }
          }
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      alert("Erro ao acessar hardware.");
      onClose();
    }
  };

  useEffect(() => {
    startLive();
    const specInterval = setInterval(() => {
      setSpectators(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 5000);

    return () => {
      clearInterval(specInterval);
      if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
      if (outAudioContextRef.current) outAudioContextRef.current.close();
      // Fix: Safely access getTracks by checking if srcObject is a MediaStream
      const stream = videoRef.current?.srcObject;
      if (stream instanceof MediaStream) {
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcription]);

  return (
    <div className="fixed inset-0 z-[60] bg-black flex flex-col animate-in fade-in duration-500 overflow-hidden">
      {/* Viewport da Câmera Principal */}
      <div className="relative flex-1 bg-zinc-900 overflow-hidden sm:max-w-md sm:mx-auto w-full">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className="absolute inset-0 w-full h-full object-cover scale-x-[-1]" 
        />
        <canvas ref={canvasRef} width="320" height="240" className="hidden" />
        
        {/* Overlay do Instagram High-Quality */}
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-4 pb-8">
          
          {/* Header Superior */}
          <div className="flex justify-between items-start pointer-events-auto">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-r from-red-600 to-pink-600 text-white text-[10px] font-black px-2.5 py-1 rounded shadow-lg animate-pulse uppercase tracking-wider">AO VIVO</div>
              <div className="bg-black/50 backdrop-blur-lg px-2.5 py-1 rounded flex items-center gap-1.5 text-white text-xs font-bold shadow-lg">
                <Users className="w-3.5 h-3.5" /> {spectators}
              </div>
            </div>
            <div className="flex gap-2">
               <button onClick={onClose} className="p-2.5 bg-black/50 backdrop-blur-lg rounded-full text-white hover:bg-black/70 transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Área Central (Mentor Speaking Indicator) */}
          <div className="flex-1 flex items-center justify-center">
            {isMentorSpeaking && (
              <div className="bg-[#c5a059]/30 backdrop-blur-xl p-4 rounded-3xl border border-[#c5a059]/50 animate-in zoom-in duration-300">
                <div className="flex items-center gap-3">
                  <div className="flex gap-1 items-end h-6">
                    <div className="w-1 bg-[#c5a059] animate-[bounce_0.6s_infinite_0.1s] h-3"></div>
                    <div className="w-1 bg-[#c5a059] animate-[bounce_0.6s_infinite_0.2s] h-5"></div>
                    <div className="w-1 bg-[#c5a059] animate-[bounce_0.6s_infinite_0.3s] h-4"></div>
                  </div>
                  <span className="text-white font-bold text-sm tracking-widest uppercase">Mentor Sábio falando...</span>
                </div>
              </div>
            )}
          </div>

          {/* Área Inferior: Chat e Reações */}
          <div className="space-y-4 pointer-events-auto">
            {/* Reações Flutuantes */}
            <div className="absolute bottom-24 right-4 h-64 w-20 overflow-hidden pointer-events-none">
              {reactions.map(r => (
                <div 
                  key={r.id} 
                  className="absolute bottom-0 text-3xl animate-[floatUp_3s_ease-out_forwards]"
                  style={{ left: `${r.left}%` }}
                >
                  {r.emoji}
                </div>
              ))}
            </div>

            {/* Chat Log */}
            <div className="max-h-56 overflow-y-auto space-y-2 no-scrollbar px-1 flex flex-col mask-fade-top">
              {transcription.map((msg) => (
                <div key={msg.id} className="flex gap-2.5 items-start animate-in slide-in-from-left-2 duration-300">
                  <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-[10px] text-white border border-white/20 ${
                    msg.role === 'Mentor' ? 'bg-[#c5a059]' : 'bg-[#4b5335]'
                  }`}>
                    {msg.role[0]}
                  </div>
                  <div className="flex flex-col">
                    <span className="font-black text-white text-[11px] drop-shadow-md tracking-tight">{msg.role}</span>
                    <span className="text-white text-xs drop-shadow-md leading-relaxed bg-black/20 backdrop-blur-sm rounded-lg px-2 py-1">{msg.text}</span>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            {/* Input e Ações */}
            <div className="flex items-center gap-2.5">
              <form onSubmit={sendChatMessage} className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Envie uma mensagem..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  className="w-full bg-white/10 backdrop-blur-xl border border-white/30 rounded-full px-5 py-3 text-white text-sm placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-[#c5a059] shadow-2xl"
                />
                <button 
                  type="submit" 
                  disabled={!chatMessage.trim()}
                  className="absolute right-2 top-1.5 p-1.5 bg-[#c5a059] rounded-full text-white disabled:opacity-30 disabled:grayscale transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
              
              <div className="flex gap-2">
                <button 
                  onClick={addReaction}
                  className="p-3 bg-white/10 backdrop-blur-xl border border-white/30 rounded-full text-white hover:scale-110 active:scale-90 transition-transform shadow-2xl"
                >
                  <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                </button>
                <button className="p-3 bg-white/10 backdrop-blur-xl border border-white/30 rounded-full text-white hover:scale-110 transition-transform shadow-2xl">
                  <Smile className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Status de Carregamento Estilizado */}
        {!isActive && (
          <div className="absolute inset-0 bg-gradient-to-br from-[#4b5335] to-[#c5a059] flex flex-col items-center justify-center text-white gap-6 z-50">
            <div className="relative">
              <div className="w-24 h-24 border-4 border-white/20 rounded-full animate-spin border-t-[#c5a059]" />
              <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-[#c5a059] animate-pulse" />
            </div>
            <div className="text-center">
              <p className="font-black tracking-[0.3em] uppercase text-sm mb-1">Iniciando Live</p>
              <p className="text-[10px] text-white/70 font-bold uppercase tracking-widest">Preparando Mentor Sábio...</p>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(1) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          100% { transform: translateY(-400px) scale(1.5) rotate(15deg); opacity: 0; }
        }
        .mask-fade-top {
          mask-image: linear-gradient(to top, black 85%, transparent 100%);
        }
        @keyframes bounce {
          0%, 100% { height: 20%; }
          50% { height: 100%; }
        }
      `}</style>
    </div>
  );
};

export default LiveSession;
